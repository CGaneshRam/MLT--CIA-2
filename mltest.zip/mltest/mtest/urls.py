from django.urls import path

from . import views

urlpatterns=[
    path('',views.home,name='home'),
    path("check",views.check,name='check'),
    path('signup',views.signup,name='signup'),
    path('new',views.new,name='new'),
    path('enter',views.enter,name='enter'),
]